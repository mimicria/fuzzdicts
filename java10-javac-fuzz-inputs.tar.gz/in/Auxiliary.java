/* /nodynamiccopyright/ */

import java.io.StringBufferInputStream;

public class Auxiliary {

}
