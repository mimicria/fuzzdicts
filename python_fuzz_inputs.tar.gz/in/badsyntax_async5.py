def foo():
    await something()
