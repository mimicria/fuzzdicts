async def foo():
    yield from []
