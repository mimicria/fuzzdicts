async def foo():
    await await fut
