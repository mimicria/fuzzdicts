async def foo(a=await something()):
    pass
