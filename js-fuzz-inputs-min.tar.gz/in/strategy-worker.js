var b = new CountQueuingStrategy({ highWaterMark: 3 });

importScripts("empty.js");
postMessage("done");
