export { f } from "./resources/resolve-export.wasm";
