'use strict';
module.exports = 1;
