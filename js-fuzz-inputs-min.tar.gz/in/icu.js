const React = {
  createElement: () => {
    "あ 🐕 🐕", function (e) {
      throw e;
    }(Error("an error"));
  }
};
const profile = /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("img", {
  src: "avatar.png",
  className: "profile"
}), /*#__PURE__*/React.createElement("h3", null, ["hello"]));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImljdS5qc3giXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsTUFBTSxLQUFLLEdBQUc7QUFDWixFQUFBLGFBQWEsRUFBRSxNQUFNO0FBQ2xCO0FBQUE7QUFBQSxNQUFpQixLQUFLLENBQUMsVUFBRCxDQUF0QixDQUFEO0FBQ0Q7QUFIVyxDQUFkO0FBTUEsTUFBTSxPQUFPLGdCQUNYLDhDQUNFO0FBQUssRUFBQSxHQUFHLEVBQUMsWUFBVDtBQUFzQixFQUFBLFNBQVMsRUFBQztBQUFoQyxFQURGLGVBRUUsZ0NBQUssQ0FBQyxPQUFELENBQUwsQ0FGRixDQURGIiwiZmlsZSI6InN0ZG91dCIsInNvdXJjZXNDb250ZW50IjpbImNvbnN0IFJlYWN0ID0ge1xuICBjcmVhdGVFbGVtZW50OiAoKSA9PiB7XG4gICAgKFwi44GCIPCfkJUg8J+QlVwiLCB0aHJvdyBFcnJvcihcImFuIGVycm9yXCIpKTtcbiAgfVxufTtcblxuY29uc3QgcHJvZmlsZSA9IChcbiAgPGRpdj5cbiAgICA8aW1nIHNyYz1cImF2YXRhci5wbmdcIiBjbGFzc05hbWU9XCJwcm9maWxlXCIgLz5cbiAgICA8aDM+e1tcImhlbGxvXCJdfTwvaDM+XG4gIDwvZGl2PlxuKTtcbiJdfQ==
