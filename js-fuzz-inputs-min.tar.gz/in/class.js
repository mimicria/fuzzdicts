'use strict';

// An exported class using ES2015 class syntax.

class Class {
  constructor() {};
  method() {};
}

module.exports = {
  Class
};
