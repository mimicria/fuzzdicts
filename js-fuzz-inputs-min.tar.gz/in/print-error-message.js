console.error('Bad command or file name');
