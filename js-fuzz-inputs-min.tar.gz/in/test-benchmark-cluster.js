'use strict';

require('../common');

const runBenchmark = require('../common/benchmark');

runBenchmark('cluster');
