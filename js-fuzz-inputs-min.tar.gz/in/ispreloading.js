const assert = require('assert');
assert(module.isPreloading);
