// This is a test script for purposes of testing the
// script initiator type in the Resource Timing feature
var testDummyValue = 0;
