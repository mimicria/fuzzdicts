/*
 * /nodynamiccopyright/
 * Auxiliary source file for ClassCycle1a.
 */

interface ClassCycle1b extends ClassCycle1a {}
