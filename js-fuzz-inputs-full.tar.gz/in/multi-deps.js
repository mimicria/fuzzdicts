'use strict';
require('fs');
require('process');
