'use strict';

// Buffer instance methods are exported as 'buf'.

function Buffer() {
}

Buffer.prototype.instanceMethod = function() {}

module.exports = {
  Buffer
};
