const test = require('node:test');

test('never ending test', () => {
  while (true);
});
