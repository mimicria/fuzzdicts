// No package.json -> should still be CommonJS as it is in node_modules
module.exports = 42;
