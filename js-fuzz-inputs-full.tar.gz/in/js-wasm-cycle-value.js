export const val = 42;
import { f } from "./js-wasm-cycle-value.wasm";
