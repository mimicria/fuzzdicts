const Countdown = require('../common/countdown');
new Countdown(2, () => {});
