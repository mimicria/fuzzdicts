import './fake_responses.py?url=empty_script.js?script-head-import-async';
import('./fake_responses.py?url=empty_script.js?script-head-import-async-dynamic').then(module => {});