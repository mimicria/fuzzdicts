// META: title=WebCryptoAPI: sign() and verify() Using ECDSA
// META: script=ecdsa_vectors.js
// META: script=ecdsa.js
// META: timeout=long

run_test();
