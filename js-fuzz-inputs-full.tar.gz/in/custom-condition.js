module.exports = 'from custom condition';
