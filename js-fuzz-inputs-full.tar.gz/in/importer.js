import './fake_responses.py?url=empty_script.js?script-head-import-defer';
import('./fake_responses.py?url=empty_script.js?script-head-import-defer-dynamic').then(module => {});