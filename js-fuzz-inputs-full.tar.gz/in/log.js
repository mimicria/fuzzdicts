export function logExec() { log.push("executed"); }
