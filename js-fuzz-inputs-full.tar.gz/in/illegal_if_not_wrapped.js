if (true) {
  return;
}
