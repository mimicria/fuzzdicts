throw new Error('fails');
