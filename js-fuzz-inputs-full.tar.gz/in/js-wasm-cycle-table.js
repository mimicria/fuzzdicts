export const tab = new WebAssembly.Table({ element: "anyfunc" });
import { f } from "./js-wasm-cycle-table.wasm";
