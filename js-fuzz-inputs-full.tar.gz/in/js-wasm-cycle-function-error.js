export const func = 42;
import { f } from "./js-wasm-cycle-function-error.wasm";
