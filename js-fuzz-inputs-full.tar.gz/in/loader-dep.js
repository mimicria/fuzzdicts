exports.format = 'module';
