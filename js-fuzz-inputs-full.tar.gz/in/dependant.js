const dependency = require('./dependency');
console.log(dependency);
