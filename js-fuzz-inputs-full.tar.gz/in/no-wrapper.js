require('module').wrapper = ['', ''];
