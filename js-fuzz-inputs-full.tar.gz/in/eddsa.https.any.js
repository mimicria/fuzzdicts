// META: title=WebCryptoAPI: sign() and verify() Using EdDSA
// META: script=eddsa_vectors.js
// META: script=eddsa.js
// META: timeout=long

run_test();
