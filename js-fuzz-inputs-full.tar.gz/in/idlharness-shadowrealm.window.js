// META: script=/resources/idlharness-shadowrealm.js

// https://console.spec.whatwg.org/

idl_test_shadowrealm(["console"], []);
