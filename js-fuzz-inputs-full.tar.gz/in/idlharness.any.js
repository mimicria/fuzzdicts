// META: script=/resources/WebIDLParser.js
// META: script=/resources/idlharness.js

// https://console.spec.whatwg.org/

idl_test(
  ['console'],
  [] // no deps
);
