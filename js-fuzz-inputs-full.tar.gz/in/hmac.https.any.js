// META: title=WebCryptoAPI: sign() and verify() Using HMAC
// META: script=hmac_vectors.js
// META: script=hmac.js
// META: timeout=long

run_test();
