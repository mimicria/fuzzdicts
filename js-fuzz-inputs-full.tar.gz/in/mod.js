'use strict';

// A module may export one or more methods.

function foo() {
}


module.exports = {
  foo
};
