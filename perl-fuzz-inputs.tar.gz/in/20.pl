my @array=(1..10); for(my $count=0;$count<10;$count++) {print "$array[$count]";}
