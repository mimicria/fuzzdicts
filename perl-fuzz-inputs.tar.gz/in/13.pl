@numbers= (1..10); print @numbers;
