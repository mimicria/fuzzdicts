print uri_unescape("%D0%BF%D1%80%D0%B8%D0%B2")
