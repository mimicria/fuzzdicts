@days = ("Mon","Tue","Wed"); unshift(@days, "Fri");
