print decode_base64("cGFzc3dvcmQ=")
