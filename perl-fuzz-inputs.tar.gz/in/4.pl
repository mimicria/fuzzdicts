print encode_base64("password")
