print uri_escape("test")
