printf "%x\n", 1234
