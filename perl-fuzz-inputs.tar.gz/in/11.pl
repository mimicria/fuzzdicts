$string = "43"; $number = 28; $result = $string + $number; print $result;
