my $a=5; if($a==5){print "The value is $a";}
