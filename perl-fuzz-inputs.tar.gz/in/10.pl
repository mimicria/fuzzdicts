$size=14; print $size
