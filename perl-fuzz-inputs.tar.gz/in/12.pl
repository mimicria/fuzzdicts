my @array=(a,b,c,d); print @array;
