say for 1..42
