$x = eval { die $! }
