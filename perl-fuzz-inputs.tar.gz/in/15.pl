my $string="This is a kind of dynamic array"; my @array; @array=split('a',$string);
