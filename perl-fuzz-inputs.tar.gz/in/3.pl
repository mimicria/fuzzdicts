while(glob "cgi-bin/*"){ print if -f }
