@days = ("Mon","Tue","Wed"); pop(@days); shift(@days);
