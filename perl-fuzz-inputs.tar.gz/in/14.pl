@array= qw/a b c d e/; print $size=scalar (@array);
