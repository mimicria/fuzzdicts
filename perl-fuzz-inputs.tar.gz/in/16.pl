@days = ("Mon","Tue","Wed"); push(@days, "Thu");
