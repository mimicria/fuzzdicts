<?php

class Test {
    function __call() {
    }
}

?>
