<?php
Class C {}
echo C::$p;
?>
