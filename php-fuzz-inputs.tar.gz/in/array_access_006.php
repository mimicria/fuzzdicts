<?php

class OverloadedArray implements ArrayAccess {
    public $realArray;

    function __construct() {
        $this->realArray = array(1,2,3);
    }

    function offsetExists($index): bool {
        return array_key_exists($this->realArray, $index);
    }

    function offsetGet($index): mixed {
        return $this->realArray[$index];
    }

    function offsetSet($index, $value): void {
        $this->realArray[$index] = $value;
    }

    function offsetUnset($index): void {
        unset($this->realArray[$index]);
    }
}

$a = new OverloadedArray;
$a[1] += 10;
var_dump($a[1]);
echo "---Done---\n";
?>
