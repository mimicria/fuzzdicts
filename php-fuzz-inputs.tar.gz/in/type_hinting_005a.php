<?php
Class C { function f(array $a) {} }

// Compatible hint.
Class D1 extends C { function f(array $a) {} }

// Class hint, should be array.
Class D2 extends C { function f(SomeClass $a) {} }
?>
