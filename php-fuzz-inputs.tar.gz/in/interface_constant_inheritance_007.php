<?php
interface A {
    private const FOO = 10;
}
?>
