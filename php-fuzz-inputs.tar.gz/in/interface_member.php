<?php

interface if_a {
    public $member;
}
?>
