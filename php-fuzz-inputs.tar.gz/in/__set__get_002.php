<?php
class Test {
    function __get($x,$y) {
    }
}

?>
