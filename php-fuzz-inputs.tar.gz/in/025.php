<?php
var_dump($_POST, $HTTP_RAW_POST_DATA);
?>
