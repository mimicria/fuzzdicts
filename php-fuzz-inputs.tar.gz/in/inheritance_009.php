<?php
class A {
    private function test() {}
}
abstract class B extends A {
    abstract function test();
}
echo 'OK';
?>
