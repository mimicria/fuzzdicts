<?php

class A {
    protected const protectedConst = 0;
}

class B extends A {
    private const protectedConst = 1;
}
?>
