<?php

interface if_a {
    function f_a();
}

$t = new if_a();

?>
