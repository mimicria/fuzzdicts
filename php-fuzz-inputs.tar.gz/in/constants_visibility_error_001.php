<?php
class A {
    private const privateConst = 'privateConst';
}

var_dump(A::privateConst);

?>
