<?php

interface if_a {
    function f_a();
}

class derived_a implements if_a {
}

?>
