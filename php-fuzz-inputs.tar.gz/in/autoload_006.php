<?php

spl_autoload_register(function ($class_name) {
    require_once(__DIR__ . '/' . strtolower($class_name) . '.inc');
    echo 'autoload(' . $class_name . ")\n";
});

var_dump(interface_exists('autoload_interface', false));
var_dump(class_exists('autoload_implements', false));

$o = new Autoload_Implements;
var_dump($o);
var_dump($o instanceof autoload_interface);
unset($o);

var_dump(interface_exists('autoload_interface', false));
var_dump(class_exists('autoload_implements', false));

?>
