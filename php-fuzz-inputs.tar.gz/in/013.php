<?php
var_dump($_POST['a']);
?>
