<?php
  class C
  {
      const c1 = D::hello;
  }

  $a = new C();
?>
