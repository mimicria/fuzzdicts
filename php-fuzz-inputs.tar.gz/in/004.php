<?php
error_reporting(0);
echo "{$_POST['a']} {$_POST['b']}" ?>
