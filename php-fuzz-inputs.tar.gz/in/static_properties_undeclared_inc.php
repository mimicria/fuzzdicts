<?php
Class C {}
C::$p++;
?>
