<?php

class fail {
    abstract function show();
}

echo "Done\n"; // shouldn't be displayed
?>
