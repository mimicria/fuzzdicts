<?php
class base {
}

class derived implements base {
}
?>
