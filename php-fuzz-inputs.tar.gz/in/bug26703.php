<?php
    highlight_string('<?php echo "foo[] $a \n"; ?>');
?>
