<?php $a=2; $b=4; $c=8; $d=$a*$b*$c; echo $d?>
