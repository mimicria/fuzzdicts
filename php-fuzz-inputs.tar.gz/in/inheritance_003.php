<?php

class A
{
    function f($x) {}
}

class B extends A
{
    function f() {}
}

?>
