<?php
class test {

  private function __construct($x) {
  }
}

$obj = new test;

echo "Done\n";
?>
