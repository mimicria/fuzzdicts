<?php
$string = "foobar";
var_dump($string[0][0][0][0]);
?>
