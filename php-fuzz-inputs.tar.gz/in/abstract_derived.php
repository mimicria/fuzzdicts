<?php

class base {
}

class derived extends base {
    abstract function show();
}

?>
===DONE===
