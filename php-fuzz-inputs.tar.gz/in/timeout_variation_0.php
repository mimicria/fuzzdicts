<?php

set_time_limit(1);

$x = true;
$y = 0;
while ($x) {
    $y++;
}

?>
never reached here
