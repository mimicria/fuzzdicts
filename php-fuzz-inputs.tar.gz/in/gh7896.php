<?php
var_dump(
    $_SERVER['FÖÖ'],
    $_ENV['FÖÖ'],
    getenv('FÖÖ')
);
?>
