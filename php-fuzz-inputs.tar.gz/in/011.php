<?php
$argc = $_SERVER['argc'];
$argv = $_SERVER['argv'];

for ($i=0; $i<$argc; $i++) {
    echo "$i: ".$argv[$i]."\n";
}

?>
