<?php
Class C {}
C::$p += 1;
?>
