<?php
spl_autoload_register(function ($name) {
    echo "In autoload: ";
    var_dump($name);
});
try {
    call_user_func("UndefC::test");
} catch (TypeError $e) {
    echo $e->getMessage(), "\n";
}
?>
