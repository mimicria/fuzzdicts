<?php
interface IA {
    public const FOO = 10;
}

echo "Done\n";
?>
