<?php
class test {

  protected function __construct($x) {
  }
}

$obj = new test;

echo "Done\n";
?>
