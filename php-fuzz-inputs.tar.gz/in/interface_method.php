<?php

interface if_a {
    function err() {}
}

?>
