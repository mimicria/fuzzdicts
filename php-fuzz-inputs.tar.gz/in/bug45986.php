<?php
rename('foo', 'bar');
?>
