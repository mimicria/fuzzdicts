<?php

class fail {
    final abstract function show();
}

echo "Done\n"; // Shouldn't be displayed
?>
