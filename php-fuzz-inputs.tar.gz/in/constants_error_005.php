<?php
  class myclass
  {
      const myConst = "$myVar";
  }
?>
