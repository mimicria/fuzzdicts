<?php

set_time_limit(1);

$a = array(1, 1);
array_map("sleep", $a);

?>
never reached here
