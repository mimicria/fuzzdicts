<?php

class Peoples implements ArrayAccess {
    public $person;

    function __construct() {
        $this->person = array(array('name'=>'Foo'));
    }

    function offsetExists($index): bool {
        return array_key_exists($this->person, $index);
    }

    function offsetGet($index): mixed {
        return $this->person[$index];
    }

    function offsetSet($index, $value): void {
        $this->person[$index] = $value;
    }

    function offsetUnset($index): void {
        unset($this->person[$index]);
    }
}

$people = new Peoples;

var_dump($people->person[0]['name']);
$people->person[0]['name'] = $people->person[0]['name'] . 'Bar';
var_dump($people->person[0]['name']);
$people->person[0]['name'] .= 'Baz';
var_dump($people->person[0]['name']);

echo "===ArrayOverloading===\n";

$people = new Peoples;

var_dump($people[0]['name']);
$people[0]['name'] = 'FooBar';
var_dump($people[0]['name']);
$people[0]['name'] = $people->person[0]['name'] . 'Bar';
var_dump($people[0]['name']);
$people[0]['name'] .= 'Baz';
var_dump($people[0]['name']);

?>
