<?php
class Test {
    function __set() {
    }
}

?>
