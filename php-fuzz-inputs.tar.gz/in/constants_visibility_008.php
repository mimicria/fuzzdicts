<?php

class Foo
{
    private const BAR = 1;
}
echo (int)defined('Foo::BAR');
?>
