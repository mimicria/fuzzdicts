<?php
Class C {}
$a = 'foo';
C::$p =& $a;
?>
