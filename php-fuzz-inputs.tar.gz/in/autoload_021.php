<?php
spl_autoload_register(function ($name) {
    echo "$name\n";
});
$a = "../BUG";
$x = new $a;
echo "BUG\n";
?>
