<?php
echo "Send headers.\n";
header_register_callback(function() { echo "Too late";});
?>
