<?php
class A {
    static const X = 1;
}
?>
