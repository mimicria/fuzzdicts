<?php
class dooh {
    public $blah;
}
$d = new dooh;
var_dump(is_subclass_of($d, 'dooh'));
?>
