<?php
class test {

  protected function __destruct() {
    echo __METHOD__ . "\n";
  }
}

$obj = new test;

?>
===DONE===
