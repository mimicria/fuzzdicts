<?php

set_time_limit(1);
register_shutdown_function("sleep", 1);
register_shutdown_function("sleep", 1);

exit(0);
?>
never reached here
