<?php
header("Content-length: 200");
echo str_repeat("a", 200);
?>
