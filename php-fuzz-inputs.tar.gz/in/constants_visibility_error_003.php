<?php

class A {
    public const publicConst = 0;
}

class B extends A {
    protected const publicConst = 1;
}
?>
