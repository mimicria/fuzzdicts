<?php

interface if_a {
    abstract private function err();
}

?>
