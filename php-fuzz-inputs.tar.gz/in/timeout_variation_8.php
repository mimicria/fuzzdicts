<?php

set_time_limit(1);

foreach (new InfiniteIterator(new ArrayIterator([1])) as $i) {
}

?>
never reached here
