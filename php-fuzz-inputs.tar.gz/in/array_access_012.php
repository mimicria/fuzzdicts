<?php

class ArrayAccessImpl implements ArrayAccess {
    private $data = array();

    public function offsetUnset($index): void {}

    public function offsetSet($index, $value): void {
        $this->data[$index] = $value;
    }

    public function offsetGet($index): mixed {
        return $this->data[$index];
    }

    public function offsetExists($index): bool {
        return isset($this->data[$index]);
    }
}

$data = new ArrayAccessImpl();
$test = 'some data';
$data['element'] = NULL; // prevent notice
$data['element'] = &$test;

?>
===DONE===
