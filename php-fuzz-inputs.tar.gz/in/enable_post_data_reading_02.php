<?php
var_dump($_FILES);
var_dump($_POST);
var_dump(file_get_contents("php://input"));
var_dump(file_get_contents("php://input"));
?>
