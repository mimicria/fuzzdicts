<?php
interface A {
    protected const FOO = 10;
}
?>
