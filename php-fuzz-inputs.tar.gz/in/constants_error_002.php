<?php
  class myclass
  {
      const myConst = array();
  }
?>
===DONE===
