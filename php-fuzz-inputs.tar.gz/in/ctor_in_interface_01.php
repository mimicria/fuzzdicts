<?php
interface constr
{
    function __construct();
}

class implem implements constr
{
    function __construct($a)
    {
    }
}

?>
