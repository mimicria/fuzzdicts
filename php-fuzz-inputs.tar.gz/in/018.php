<?php
var_dump($_POST['a']);
var_dump($_POST['b']);
?>
