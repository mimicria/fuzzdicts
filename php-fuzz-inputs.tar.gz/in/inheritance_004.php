<?php

class A
{
function f() {}
}

class B extends A
{
    function f($x) {}
}

?>
