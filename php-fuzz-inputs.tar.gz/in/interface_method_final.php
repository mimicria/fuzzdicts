<?php

class if_a {
    abstract final function err();
}

?>
