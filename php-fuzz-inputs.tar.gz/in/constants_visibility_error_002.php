<?php
class A {
    protected const protectedConst = 'protectedConst';
}

var_dump(A::protectedConst);

?>
