<?php
spl_autoload_register(function ($name) {
  echo "IN:  autoload($name)\n";

  static $i = 0;
  if ($i++ > 10) {
      echo "-> Recursion detected - as expected.\n";
      return;
  }

  class_exists('UndefinedClass' . $i);

  echo "OUT: autoload($name)\n";
});

var_dump(class_exists('UndefinedClass0'));
?>
