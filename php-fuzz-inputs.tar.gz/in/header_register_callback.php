<?php
header_register_callback(function() { echo "sent";});
?>
