<?php

set_time_limit(1);

sleep(1);
sleep(1);

?>
never reached here
