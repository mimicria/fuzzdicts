<?php
class A {
    abstract const X = 1;
}
?>
