<?php
  class myclass
  {
      const myConst = "hello";
      const myConst = "hello again";
  }
?>
