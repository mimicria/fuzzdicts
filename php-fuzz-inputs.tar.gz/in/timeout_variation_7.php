<?php

set_time_limit(1);

$y = 0;
for ($i = 0; $i < INF; $i++) {
    $y++;
}

?>
never reached here
