<?php

set_time_limit(1);

call_user_func('sleep', 1);
call_user_func('sleep', 1);

?>
never reached here
