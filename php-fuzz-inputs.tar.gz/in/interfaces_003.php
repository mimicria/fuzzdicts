<?php

class MyObject {}

interface MyInterface
{
    public function __construct(MyObject $o);
}

class MyTestClass implements MyInterface
{
    public function __construct(MyObject $o)
    {
    }
}

$obj = new MyTestClass;

?>
===DONE===
