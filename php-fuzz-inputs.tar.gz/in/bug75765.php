<?php

try {
    class A extends B {}
} catch (Error $e) {
    var_dump(class_exists('A'));
    var_dump(class_exists('B'));
    throw $e;
}

?>
