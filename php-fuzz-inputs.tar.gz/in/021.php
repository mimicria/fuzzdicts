<?php
var_dump($_FILES);
var_dump($_POST);
?>
