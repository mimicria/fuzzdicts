<?php

class Base
{
    private final function __construct()
    {
    }
}
class Extended extends Base
{
    public function __construct()
    {
    }
}

?>
