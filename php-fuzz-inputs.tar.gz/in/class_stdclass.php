<?php

$obj = new stdClass;

echo get_class($obj)."\n";

echo "Done\n";
?>
