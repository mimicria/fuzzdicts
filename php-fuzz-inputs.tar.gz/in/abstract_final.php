<?php

class fail {
    abstract final function show();
}

echo "Done\n"; // Shouldn't be displayed
?>
