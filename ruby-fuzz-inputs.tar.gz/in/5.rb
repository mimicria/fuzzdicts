b << �Brian� << 48 << 220



print "B: ", b.join(' '), "\n"



print "pop: ", b.pop, "\n"



print "shift: ", b.shift, "\n"



print "C: ", b.join(' '), "\n"



b.delete_at(2)



b.delete('alex')



print "D: ", b.join(' '), "\n"