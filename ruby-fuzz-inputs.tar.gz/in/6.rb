=begin



Ruby program to find Area of Rectangle.



=end



# input length and breadth, and



# convert them to float value



puts "Enter length:"



l=gets.chomp.to_f



puts "Enter width:"



w=gets.chomp.to_f



# calculating area



area=l*w



# printing the result



