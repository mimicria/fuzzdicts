# Ruby program to create a directory

if (Dir.mkdir("mydir") == 0)
	puts "Directory created successfully";
else
	puts "Directory creation failed";
end
