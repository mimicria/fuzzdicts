# Ruby program to calculate the 
# area of Cube

side=0.0;
area=0.0;

print "Enter side: ";
side = gets.chomp.to_f;  

area = 6.0 * side * side;

print "Area of Cube is: ",area;
