=begin



Ruby program to add two numbers.



=end



# input the numbers and converting



# them into an integer



puts "Enter first value: "



num1=gets.chomp.to_i



puts "Enter second value: "



num2=gets.chomp.to_i



# finding sum



sum=num1+num2



# printing the result



puts "The sum is #{sum}."