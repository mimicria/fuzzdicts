class UPSTACK



# The initialize method is the constructor. The @val is



# an object value.



def initialize(v)



@val = v



end



# Set it and get it.



def set(v)



@val = v



end



def get



return @val



end



end


a = Upstack.new(10)



b = Upstack.new(22)



print "A: ", a.get, " ", b.get,"\n";



b.set(34)



print "B: ", a.get, " ", b.get,"\n";