s = "Good morning.How are you?"



print s.length, " [" + s + "]\n"



# Selecting a character in a string gives an integer ascii code.



print s[4], "\n"



printf("%c\n", s[4])



# The [n,l] substring gives the starting position and length. The [n..m]



# form gives a range of positions, inclusive.



print "[" + s[4,4] + "] [" + s[6..15] + "]\n"



print "Wow " * 3, "\n"



print s.index("there"), " ", s.index("How"), " ", s.index("bogus"), "\n"



print s.reverse, "\n"



a = [ 45, 3, 19, 8 ]



b = [ 'sam', 'max', 56, 98.9, 3, 10, 'jill' ]



print (a + b).join(' '), "\n"



print a[2], " ", b[4], " ", b[-2], "\n"



print a.sort.join(' '), "\n"



a << 57 << 9 << 'phil'



print "A: ", a.join(' '), "\n"
