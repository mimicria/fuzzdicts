=begin 
Ruby program to print Hello World.
=end

puts "Hello World!"
print "Hello World!"
puts "Hello World!"
