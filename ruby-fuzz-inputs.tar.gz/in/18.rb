# Ruby program to demonstrate 
# the exponential operator

num1 = 2
num2 = 5

num3 = num1 ** num2
puts("Exponential: ",num3)
