=begin
Ruby program to find the empty set 
with Set.empty?() method.
=end

require 'set'

Vegetable = Set.new(["potato","brocolli","broccoflower","lentils","peas","fennel","chilli","cabbage"])
Fruits = Set.new(["Apple","Mango","Banana","Orange","Grapes"])

Vegetable.merge(Fruits)

if Vegetable.empty?()
	puts "Set is empty"
else
	puts "Set is not empty"
end
