# Ruby program to sleep thread execution 
# for a specific time.

# First Thread method
def ThreadFun1()
	$i = 0;
	while $i<5 do
		puts "First Thread running";
		$i += 1;

		# sleep thread for 1 second
		sleep(1);
	end
end

# Second Thread method
def ThreadFun2()
	$i = 0;
	while $i<5 do
		puts "Second Thread running";
		$i += 1;

		# sleep thread for 1 second
		sleep(1);
	end
end

# Create thread objects
t1 = Thread.new{ThreadFun1()};
t2 = Thread.new{ThreadFun2()};

# Join created thread.
t1.join();
t2.join();
