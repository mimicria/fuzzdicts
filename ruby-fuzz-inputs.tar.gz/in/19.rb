# Ruby program to calculate the 
# base 2 logarithm of the given value

print "Enter value: ";
num = gets.chomp.to_i;  

Log2 = Math.log2(num);

print "Base 2 logarithm is: ",Log2;
