# Ruby program to read entire text 
# from the existing file

# Open an existing file.
fobj = File.new("MyFile.txt", "r"); 

# Read entire data from existing file.
print "File Text: ",fobj.read();

# Close file object
fobj.close();  
