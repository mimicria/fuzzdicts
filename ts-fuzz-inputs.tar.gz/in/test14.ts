let x: unknown = 'hello';
console.log((x as string).length);