let u = true;
u = "string";
Math.round(u);