class C {
   foo();
}