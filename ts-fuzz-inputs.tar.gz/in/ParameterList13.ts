interface I {
    new (public x);
}