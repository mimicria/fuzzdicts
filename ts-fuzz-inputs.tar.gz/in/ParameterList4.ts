function F(public A) {
}