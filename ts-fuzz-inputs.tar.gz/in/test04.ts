const json = JSON.parse("55");
console.log(typeof json);