function A(): (public B) => C {
}