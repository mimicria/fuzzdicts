class C {
  constructor();
}