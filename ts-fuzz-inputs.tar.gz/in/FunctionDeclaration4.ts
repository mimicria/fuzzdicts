function foo();
function bar() { }