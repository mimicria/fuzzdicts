let ourTuple: [number, boolean, string];
ourTuple = [5, false, 'Coding God was here'];