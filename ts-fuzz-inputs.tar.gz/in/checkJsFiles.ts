// @allowJs: true
// @checkJs: true
// @noEmit: true

// @fileName: a.js
var x = "string";
x = 0;