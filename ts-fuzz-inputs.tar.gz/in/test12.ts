function getTime(): number {
  return new Date().getTime();
}