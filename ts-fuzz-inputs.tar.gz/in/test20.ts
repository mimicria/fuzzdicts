const nameAgeMap: Record<string, number> = {
  'Alice': 21,
  'Bob': 25
};