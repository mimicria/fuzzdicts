class C123 {
    [s: string]: number;
    constructor() {
    }
}