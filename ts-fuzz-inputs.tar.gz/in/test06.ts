const names: string[] = [];
names.push("Dylan");