class Person {
  name: string;
}

const person = new Person();
person.name = "Jane";