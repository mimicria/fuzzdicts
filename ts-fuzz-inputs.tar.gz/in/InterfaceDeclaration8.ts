interface string {
}