function multiply(a: number, b: number) {
  return a * b;
}